package com

import scala.xml.XML

object xmlParse {

  def main(args: Array[String]): Unit = {

    val xml=""" <activations>
              |    <activation timestamp="1225499258" type="phone">
              |        <account-number>316</account-number>
              |        <device-id>
              |            d61b6971-33e1-42f0-bb15-aa2ae3cd8680
              |        </device-id>
              |        <phone-number>5108307062</phone-number>
              |        <model>iFruit 1</model>
              |    </activation>
              |    <activation timestamp="1225499258" type="phone">
              |        <account-number>315</account-number>
              |        <device-id>
              |            d61b6971-33e1-42f0-bb15-aa2ae3cd8680
              |        </device-id>
              |        <phone-number>5108307062</phone-number>
              |        <model>iFruit 2</model>
              |    </activation>
              |</activations>""".stripMargin

    val nodes=XML.loadString(xml)
    val node=nodes \ "activation"

    val itr = node.toIterator
   // println(node)
    for (a <-itr)
      {
        print(a  \ "model")
        println(a  \ "account-number")

      }



   // println(node \ "activation" \ "model")



  }

}

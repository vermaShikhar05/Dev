package com.streaming

object BasicOperations {

  def main(args:Array[String]):Unit={


  }
}

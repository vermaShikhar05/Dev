package com.rdd
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.Row
import org.apache.spark.sql.Encoders
import scala.xml.Node
import org.apache.spark.sql._
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
case class xmData(model:String,accountNumber:String)
object BasicOperations {

  def main(args:Array[String]):Unit={

    val sc=new SparkContext(new SparkConf().setMaster("local").setAppName("Rdd Operations"))
    val spark=SparkSession.builder().master("local[*]").appName("").getOrCreate()
    import spark.implicits._
    val fileRdd=sc.textFile("data/input/inp.txt")
    val xmlFile=sc.wholeTextFiles("data/xml/")
val node=xmlFile.flatMap(x=>scala.xml.XML.loadString(x._2) \ "activation")
import org.apache.spark.sql.expressions._
    val data=node.map(x=>xmData((x \ "model").text,(x \"account-number").text))
data.foreach(println)
    val map=data.map(f=> xmData(f.split(":")(0),f.split(":")(1)))
    val ro=data.map(f=> Row(f.split(":")(0),f.split(":")(1)))
import spark.implicits._
    val ds=spark.createDataset(map)
    ds.persist(StorageLevel.MEMORY_ONLY)
    val df=spark.createDataFrame(ro,Encoders.product[xmData].schema)
spark.createDataset(data)

    //df.show()

    //ds.show()
    //data.collect().foreach(println)

    //.flatMap(x=>XMLx._2)

  }

  def nodeItr(xml:String):Iterator[Node]={

  val nodes=scala.xml.XML.loadString(xml)
    val node=nodes \ "activation"
   node.toIterator
  }
def getModel(rec:Node):String={
 val model= rec \ "model"
  model.text
}
  def getAcc(rec:Node):String={
    val model= rec \ "account-number"
    model.text
  }



}

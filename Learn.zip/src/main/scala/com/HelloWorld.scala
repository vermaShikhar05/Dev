package com

import org.apache.spark.sql.SparkSession

object HelloWorld {

  def main(args: Array[String]): Unit = {

    val spark= SparkSession.builder().appName("hello").master("local[*]").getOrCreate()
val csv=spark.read.csv("data/input/inp.txt")
    csv.show

  }
}

package com.dataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object Crime {
  def main(args: Array[String]): Unit = {
    val spark=SparkSession.builder().appName("crimes").master("local[*]").getOrCreate()
    import spark.implicits._
    val data= spark.read.option("header","true").csv("data/Crime/Crimes_-_2020.csv")
    //data.groupBy($"Primary Type").agg(count(lit(1)).as("count")).orderBy($"count".desc).show()
 // data.withColumn("month",substring($"Date",1,2)).groupBy($"month",$"Primary Type").agg(count(lit(1))).show(false)
    //data.groupBy($"Location Description",$"Primary Type").agg(count(lit(1)).as("count")).orderBy($"count".desc).imit(3).show(false)
    //data.show

    data.withColumnRenamed("case number","case_number").
      withColumnRenamed("fbi code","fbi_code").
      withColumnRenamed("Community Area","Community_Area").
      select($"ID",$"case_number").createOrReplaceTempView("tmpVier")//.write.format("avro").saveAsTable("crime_av")
    spark.sql("show tables").show()
    spark.sql("create database db")
    spark.sql("use db")
    spark.catalog.createTable("opavr","data/opavro","avro")
    spark.sql("show databases").show()
    spark.sql("show tables").show()
    spark.sql("select * from db.opavr ").limit(3).show()
  //  data.write/*.option("compression","lzo")*/.saveAsTable("crime")

  }
}

package com.dataFrame
import org.apache.spark.sql.{Column, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions._
import org.apache.spark.sql.avro._


case class Cont(name:String , count:Long)

object TsvRead {
  def main(args: Array[String]): Unit = {

    val spark=SparkSession.builder().appName("Schema Read").master("local[*]").getOrCreate()
import spark.implicits._
    spark.sparkContext.setLogLevel("WARN")
    val data=spark.read.format("csv").option("delimiter","|")
      .schema("name String,lname String, age Int,dept String").load("data/csvTest/data.txt")
    /*val df=data.withColumn("rank",rank().over(Window.partitionBy($"dept").orderBy($"age"))).filter($"rank".<(3))
      //select(concat($"name",lit(" "),$"lname").as("full name"))
    data.join(df,data("name")===df("name"),"left_anti")//
    // .show(false)
data.groupBy($"dept").agg(sum($"age").as("sum_age")).show()
    data.withColumn("avg_age",avg($"age") over(Window.partitionBy($"dept"))).filter($"age".>($"avg_age")).show
*/
    case class Cont(name:String , count:Long)
val tbl_name="ea_common.cse_ref"
val data1=spark.sql("select * from ea_common.cse_ref limit 0")
    val cols=data1.columns
    val colm= Array("url_crto_thumbnail_photo_nm","clsd_by_selfservice_usr_cd","selfservice_commented_cd","vsbl_selfservice_ptl_cd","missed_turnaround_tm_cd","new_selfservice_cmt_cd","e1fixedasset_chang_35_nm","enttlmt_prs_strt_tm_cd","enttlmt_prs_end_tm_cd","url_crto_pfl_photo_nm","wrld_rgn_sb_rgn_3_nm","lnk_to_reportdashboard_nm","wrld_rgn_sb_rgn_2_nm","last_mfyd_by_i_40_nm","clsd_frst_cntc_48_cd","users_to_be_add_to_grp_nm","wrld_rgn_sb_rgn_nm","turnaround_t_60_cd","cse_age_bsn_dys_dt","sys_modstam_41_cd","clsd_when_crtd_cd","ctry_submitter_nm","lg_xtrn_dcmt_lnk_nm","rec_typ_i_118_nm","techdirect_cse_id_nm","last_stts_chg_cd","stateprovinc_3_nm","crtd_by_i_38_nm","cse_exch_stts_nm","wrld_rgn_rgn_nm","cse_comments_nm","last_reference_13_dt","last_mfy_39_dt","techdirect_notes_nm","admincasesla_cd","tm_wth_sprt_cd","xtrn_cse_id_nm","mlstn_stts_nm","prnt_cse_id_nm","enttlmt_id_nm","submitte_2_nm","bsn_hrs_id_nm","techdirect_stts_nm","zipposta_9_cd","tgt_subsegment_nm","cntct_eml_nm","xtrn_assignee_nm","sls_cvrg_sg_4_nm","cse_org_2_nm","cntct_i_9_nm","cse_aging_cd","eml_add_14_nm","estmd_totl_hrs_cd","rqst_ty_3_nm","cntct_fax_nm","rqst_2_nm_1","chg_rqst_cd","cse_curr_cd","own_i_33_nm","acct_i_4_nm","stopped_since_cd","query_tm_cd","cntct_ph_nm","cntct_mbl_nm","rsln_dtls_nm","cse_rs_2_nm","it_cse_clsfn_nm","rsln_cgy_nm","rqstd_by_nm","stt_130_nm","cse_i_2_nm","stopped_cd","bsn_ar_grp_nm","pri_lvl_cd","wrld_rg_nm","new_acct_nm","ctr_56_nm","asst_id_nm","rqst_sz_nm","qt_ur_2_nm","fldr_aprvd_nm","qt_dt_2_nm","crt_37_dt","dlt_34_cd","cse_typ_nm","cls_15_cd","fldr_spr_usr_nm","rg_29_nm","cls_2_dt","d_128_nm","topic_ur_2_nm","pr_12_nm","rply_stt_2_nm","esctd_cd","rqstd_fldr_nm","opt_4_nm","q_116_nr","aprvd_fldr_nm","sb_7_nm","spr_usr_vrfd_cd","scn_2_nm","aprvl_dtl_nm","src_id_nm","last_vw_12_dt","st_6_nm","accts_nr","tgtd_impn_dt","du_5_dt","impn_own_nm","exst_fldr_nm","ct_3_nm","tgt_sgm_nm","cs_nr","c_2_nm","b_nm","vrs_3_nm","p_4_nm","jfcn_nm","crto_nm","qstn_id_nm","topi_nm","prod_i_nm","zn_id_nm")
       for(str <- cols.diff(colm))
      {
        val cnt=spark.sql(s"select ${str} from ${tbl_name} where ${str} is not null").count()

    val df=Seq(Cont(str,cnt))
        df.toDF().write.mode("append").csv("counttest1")
      }

  }
}
//ins_gmt_dt|235970282|
//|     fl_nm|235970282|
//+----------+---------+
/*+-----+-----+---+----+----+
| name|lname|age|dept|rank|
+-----+-----+---+----+----+
|shyam|kumar| 12|  IT|   1|
| shiv|kumar| 13|  IT|   2|
|  ram|Kumar| 21|  CS|   1|
|  lax|kumar| 25|  CS|   2|
+-----+-----+---+----+----+*/
/*ram|Kumar|21|CS
lax|kumar|25|CS
lav|kumar|26|CS
kush|kumar|28|CS
shyam|kumar|12|IT
shiv|kumar|13|IT*/
package com.dataFrame

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SparkSession

object updateLogic {
  def main(args: Array[String]): Unit = {

    val spark=SparkSession.builder.appName("DF Operations").master("local[*]").getOrCreate()
    val file1=spark.read.option("header","true").option("sep","|").csv("data/csvTest/data.txt")
    val file2=spark.read.option("header","true").option("sep","|").csv("data/csvTest/data_update")
  file1.createOrReplaceTempView("old")
    file2.createOrReplaceTempView("update")

    spark.sql(
      """
        |select * from
        |(select fname,lname,age,dep,time,
        |row_number() over (partition by fname order by time desc) as row
        |from (select fname,lname,age,dep,time from old union select fname,lname,age,dep,time from update)) where row =1
        |
        |""".stripMargin).show()
  }

}

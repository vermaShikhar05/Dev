package com.dataFrame
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
object CCATest {

  def main(args: Array[String]): Unit = {

      val spark=SparkSession.builder().master("local[*]").appName("CCA_TEST").getOrCreate()

    //spark.read.json("data/data-master/nyse_all/output/problem3/data/nyse_data_json").show()
    //spark.read.json("data/data-master/nyse_all/output/problem3/data/nyse_data_json").printSchema()
   // println(spark.read.json("data/data-master/nyse_all/output/problem3/data/nyse_data_json").count())
/*
    val nyse=spark.read.text("data/data-master/nyse_all/nyse_data")
    nyse.createOrReplaceTempView("coun")
    spark.sql("select cast( count(*) as String) from coun").coalesce(1).write.text("data/data-master/nyse_all/output/problem1/data/nyse_count")
*/
/*val nyse=spark.read.schema("stockticker String,tradedate String,openprice Double,highprice Double,lowprice Double,closeprice Double, volume Int").csv("data/data-master/nyse_all/nyse_data")
    //nyse.select(substring(col("tradedate"),0,4)).show(1)
    nyse.filter(substring(col("tradedate"),0,4).===("2010"))
      .select("stockticker").orderBy(asc("stockticker")).distinct()
      .coalesce(1).write.text("data/data-master/nyse_all/output/problem2/data/unique_stocks")*/
/*val meta=spark.read.option("sep","|").csv("data/data-master/nyse_all/nyse_stocks")
    val data=spark.read.csv("data/data-master/nyse_all/nyse_data")
      data.filter(col("_c6").===(0)).
      join(meta,data("_c0").===(meta("_c0"))).orderBy(meta("_c0")).select(meta("_c1")).coalesce(1)
        .write.text("data/data-master/nyse_all/output/problem5/data/untracked_stocks")*/

    /*spark.read.schema(""" stockticker String,tradedate Long,openprice Double,highprice Double,lowprice Double,closeprice Double,volume Long""").
      csv("data/data-master/nyse_all/nyse_data.").orderBy(asc("tradedate"),asc("stockticker"))
      .coalesce(8).write

      .json("data/data-master/nyse_all/output/problem3/data/nyse_data_json")*/
/*
val data=spark.read.schema("stockticker String,tradedate Long,openprice Double,highPrice Double,lowPrice Double,closePRice Double,volume Long")
  .csv("data/data-master/nyse_all/nyse_data")
    val meta =spark.read.option("sep","|").csv("data/data-master/nyse_all/nyse_stocks")
    data.join(meta,data("stockticker").===(meta("_c0")),"left").
      select(col("stockticker"),col("tradedate"),col("openprice"),col("highprice")
      ,col("lowprice"),col("closeprice"),col("volume"),
        expr("case when _c1 is null then 'STOCK NAME NOT AVAILABLE' else _c1 end").as("stockname"))
      .orderBy(asc("tradedate"),asc("stockticker")).show(200)

*/
import org.apache.spark.sql.expressions._
    import spark.implicits._
//import org.apache.spark.sql.fnctions._
    val otherPeople = spark.read.option("multiline","true").json("""data/json/file.json""")
    otherPeople.select("address.city").filter($"".between(12,12)).
      withColumn("rank",rank() over(Window.partitionBy("") orderBy($"")))
        .groupBy($"").agg(sum($"").as("a")).filter($"a".between)
    otherPeople.printSchema()
    //spark.read.format("jdbc").option(""",""")
    /*
    *dbtable
    * url
    * user
    * password
     */
    /*
     */
      /*.coalesce(8).write.option("sep",";")
      .csv("data/data-master/nyse_all/output/problem6/data/stock_data_with_name")
*/
/*
spark.sparkContext.setLogLevel("WARN")
    val data=spark.read.csv("data/data-master/nyse_all/nyse_data")
    val meta=spark.read.option("sep","|").csv("data/data-master/nyse_all/nyse_stocks")
    //data.join(meta,data("_c0").===(meta("_c0")),"left").filter(meta("_c1").isNull).select(data("_c0")).distinct().orderBy(asc("_c0")).show()
    println(meta.join(data,meta("_c0").===(data("_c0")),"left_anti").count())
*/
     // .where("_c1 is null")
    //  .select(data("_c0")).orderBy(asc("_c0")).count())

      //.write.text("data/data-master/nyse_all/output/problem4/data/no_stock_name")


/*    spark.sql("create database devsh")
    val data=spark.read.schema(
      """
        |stockticker String,
        |tradedate Long,
        |openprice Double,
        |highprice Double,
        |lowprice Double,
        |closePrice Double,
        |volume Long
        |""".stripMargin).csv("data/data-master/nyse_all/nyse_data/")
    data.select(data("*")).orderBy(asc("tradedate"),desc("volume")).coalesce(4)
      .write.format("avro").saveAsTable("devsh.nyse_data_avro")
    spark.sql("use devsh")*/
//println(spark.read.format("avro").load("spark-warehouse/devsh.db/nyse_data_avro").count())
    //spark.sql("select count(*) from devsh.nyse_data_avro ").show(4)

      .withColumn("colName",sum("") over(Window.partitionBy("") orederBy("")))
  }
}

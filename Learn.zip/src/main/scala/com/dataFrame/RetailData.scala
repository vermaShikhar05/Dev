package com.dataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.avro
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions._

object RetailData {

  def main(args: Array[String]): Unit = {

val spark=SparkSession.builder().appName("RetailDB").master("local[*]").getOrCreate()
    import spark.implicits._
    spark.sparkContext.setLogLevel("WARN")
   /* //val cus=spark.read.schema(
      """ cus_id Int,cusFname String,cusLname String,email String,
        |pass String,street String,City String,state String,zipcode String""".stripMargin).csv("data/retail_db/customers")
    //val order=spark.read.schema("""order_id Int, order_date Timestamp,order_customer_id Int,order_status String""").csv("data/retail_db/orders")
    //cus.show()
  //  order.filter($"order_customer_id".===(339)).show()
//cus.agg(count(lit(1)),sum(expr("case when(state='TX') then 1 else 0 end")).as("TX_count")).show()
   // cus.groupBy($"state").agg(count(lit(1)).as("count_st")).orderBy($"count_st".desc).show()
    //val inactiveCus=cus.join(order,cus("cus_id")===order("order_customer_id"),"left_outer").filter($"order_customer_id".isNull).select(cus("*"))
   // spark.read.table("InactiveCustomer")//.show()
    //inactiveCus.write.saveAsTable("InactiveCustomer")
*/
   /*v/*al order=spark.read.json("data/data-master/retail_db_json/orders")
    val order_items=spark.read.json("data/data-master/retail_db_json/order_items")*/*/
   /* order_items.createOrReplaceTempView("oritem")
    order.createOrReplaceTempView("order")
    spark.sql(
      """ select order_date,order_status, sum(order_item_subtotal) over(partition By(order_date)) as revenue
        |from order o join oritem oi
        |on o.order_id= oi.order_item_order_id
        |where o.order_status in ("CLOSED","COMPLETE")
        |
        |order by revenue desc
        |""".stripMargin).show()

      order.join(order_items,order("order_id")===order_items("order_item_order_id").and(order("")===order_items(""))).filter(order("order_status")
      .isin("CLOSED","COMPLETE"))
      .withColumn("revenue",sum(order_items("order_item_subtotal"))
      over(Window.partitionBy(order("order_date")))).orderBy(desc("revenue")).select($"order_date",$"order_status",$"revenue").show()
        //.orderBy("revenue")
      //.withColumn("rank",rank() over(Window.orderBy(desc("Revenue"))))
      //.limit(3).show(false)


    //order.show()
    //order_items.show()
   // order.join(order_items,order("order_id")===order_items("order_item_order_id")).filter(order("order_status")
      .isin("CLOSED","COMPLETE")).groupBy(order("order_date")).agg(round(sum(order_items("order_item_subtotal")),2).as("Revenue"))
      .withColumn("rank",rank() over(Window.orderBy(desc("Revenue")))).show()
    //.limit(3).show(false)*/


    val order=spark.read.json("data/data-master/retail_db_json/orders")
    val order_items=spark.read.json("data/data-master/retail_db_json/order_items")

order.show()
    order.withColumn("order_status_l",lower(col("order_status")))
      .drop("order_status").withColumnRenamed("order_status_l","order_status").show()




  }
}

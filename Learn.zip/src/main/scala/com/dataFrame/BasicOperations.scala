package com.dataFrame
import org.apache.spark.sql.Encoders
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession, types}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.avro._
import org.apache.spark.sql.SaveMode
case class data(name:String,age:Int)
object BasicOperations {

  def main(args:Array[String]):Unit={

    val spark=SparkSession.builder.appName("DF Operations").master("local[*]").getOrCreate()
    val sp=SparkSession.builder().appName("DB").master("local[*]").getOrCreate()
    import spark.implicits._
  val Schema= StructType(List( StructField("name",StringType),StructField("age",IntegerType)))
    val fileDF: DataFrame =spark.read.format("csv").schema(Schema).load("data/input/inp.txt")
   // fileDF.write.mode("overwrite").format("orc").option("compression","lzo").save("data/oporc")
    val avrodat=spark.read.format("orc").load("data/oporc")

    //avrodat.select(concat($"name",$"age")).show
  //  avrodat.write.saveAsTable("fullName")
    //sort based on their age
    
    //avrodat.sort($"age".desc).limit(2).sort($"age".asc).limit(1).show
    /*fileDF.groupBy($"name").max("age").show
    fileDF.agg(max($"age"),min($"age")).show
    //fileDF.agg(grouping($"name")).show
    fileDF.createOrReplaceTempView("tbl")
    spark.sql("select max(age),min(age) from tbl")
    fileDF.withColumn("date",lit(current_timestamp()))

    val ds=fileDF.as[data]
    *///ds.map(f=> f.name.toInt).show()
    //spark.createDataset(fileDF,Encoders.Product[data].s)

//
 //   fileDF.printSchema

  }
}

package com.dataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object FlightData {

  def main(args: Array[String]): Unit = {


val spark=SparkSession.builder().appName("FlightData").master("local[*]").getOrCreate()
import spark.implicits._
    val data=spark.read.parquet("data/FlightData")
  //  data.show(false)
    //data.printSchema()
    //count of flight count of delay flight count of on time flight
val dateData=data.withColumn("date",concat($"Year",lpad($"Month",2,"0")
      ,lpad($"DayofMonth",2,"0"))).as("date")
 //.select(date_format(to_date($"date","yyyyMMdd"),"EE")).show()
     dateData.groupBy("date")
    .agg(count(lit(1)),sum(expr("case when IsArrDelayed='YES' then 1 else 0 end"))
      .as("arrival_delay_count"),sum(expr("case when IsDepDelayed='YES' then 1 else 0 end"))
      .as("dep_delay_count") ).orderBy($"date".asc)
    .show(false)
  }
}
